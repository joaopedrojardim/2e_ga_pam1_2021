import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  gasolina = 12;
  etanol = 0;
  resposta = 0;
  imagens =  'interrogacao.png';
  constructor() {}

  calcular(): void{
    this.resposta = this.etanol / this.gasolina;
    if(this.resposta >= 0.7){
      this.imagens = 'gasolina.jpg';
    }else if (this.resposta <= 0.7){
      this.imagens = 'etanol.jpg';
    }else{
      this.imagens = 'empate.jpg';
    }
  }
}
