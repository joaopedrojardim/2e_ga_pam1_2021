import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  gasolina = 0;
  etanol = 0;
  resposta;
  combustiveis = [
    'gasolina.jpg',
    'etanol.jpg',
    'empate.jpg',
    'erro.jpeg'
  ];
  nomes = [
    'Gasolina',
    'Etanol',
    'A sua preferencia',
    'Valores invalidos',
  ];
  tela = '';
  imagens =  'interrogacao.png';

  constructor() {}


  calcular(): void{
    this.resposta = this.etanol/this.gasolina;
    if(this.resposta > 0.7){
        this.imagens = this.combustiveis[0];
        this.tela = this.nomes[0];
    }else if (this.resposta < 0.7){
        this.imagens = this.combustiveis[1];
        this.tela = this.nomes[1];
    }else if (this.resposta === 0.7){
        this.imagens = this.combustiveis[2];
        this.tela = this.nomes[2];
    }else{
      this.imagens = this.combustiveis[3];
      this.tela = this.nomes[3];
    }
  }
}
